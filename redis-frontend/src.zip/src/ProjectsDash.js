import React, { useState, useEffect } from 'react';
import { FaTools, FaLeaf, FaRoad, FaHospital, FaSchool, FaEdit, FaSave, FaTrash, FaPlus, FaTimes, FaCalendarAlt } from 'react-icons/fa';
import { CircularProgressbar, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';
import './ProjectsDash.css'; // Import your CSS file for styling

const ProjectsDashboard = () => {
  // Function to format date to YYYY-MM-DD for input[type="date"]
  const formatDateForInput = (dateString) => {
    if (!dateString) return '';
    
    try {
      // Try to parse the date string
      const date = new Date(dateString);
      // Check if it's a valid date
      if (isNaN(date.getTime())) return '';
      
      // Format the date as YYYY-MM-DD
      return date.toISOString().split('T')[0];
    } catch (error) {
      return '';
    }
  };
  
  // Function to format date for display
  const formatDateForDisplay = (dateString) => {
    if (!dateString) return '';
    
    try {
      const date = new Date(dateString);
      // Check if it's a valid date
      if (isNaN(date.getTime())) return dateString; // Return original if invalid
      
      return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    } catch (error) {
      return dateString; // Return original if there's an error
    }
  };

  // Initial project data
  const initialProjects = [
    {
      id: "P01",
      title: "Road Improvement",
      description: "Repairing and upgrading barangay roads for better accessibility",
      budget: 1500000,
      spent: 850000,
      startDate: "2025-01-15", // Format changed to YYYY-MM-DD
      targetCompletion: "2025-06-30", // Format changed to YYYY-MM-DD
      progress: 65,
      icon: "FaRoad", // Store icon as string for Redis compatibility
      color: "#3498db",
      isEditing: false
    },
    {
      id: "P02",
      title: "Health Center Renovation",
      description: "Expanding facilities and upgrading equipment at the local health center",
      budget: 2000000,
      spent: 1200000,
      startDate: "2024-11-10", // Format changed to YYYY-MM-DD
      targetCompletion: "2025-04-15", // Format changed to YYYY-MM-DD
      progress: 48,
      icon: "FaHospital", // Store icon as string for Redis compatibility
      color: "#e74c3c",
      isEditing: false
    },
    {
      id: "P03",
      title: "Community Garden",
      description: "Creating sustainable community gardens for local food production",
      budget: 500000,
      spent: 450000,
      startDate: "2025-02-20", // Format changed to YYYY-MM-DD
      targetCompletion: "2025-05-20", // Format changed to YYYY-MM-DD
      progress: 90,
      icon: "FaLeaf", // Store icon as string for Redis compatibility
      color: "#2ecc71",
      isEditing: false
    },
    {
      id: "P04",
      title: "School Facility Upgrade",
      description: "Improving classrooms and learning facilities at the barangay elementary school",
      budget: 1800000,
      spent: 650000,
      startDate: "2025-03-01", // Format changed to YYYY-MM-DD
      targetCompletion: "2025-08-30", // Format changed to YYYY-MM-DD
      progress: 35,
      icon: "FaSchool", // Store icon as string for Redis compatibility
      color: "#f39c12",
      isEditing: false
    }
  ];

  // Available icons for new projects
  const availableIcons = [
    { name: "Road", icon: <FaRoad />, iconKey: "FaRoad", color: "#3498db" },
    { name: "Hospital", icon: <FaHospital />, iconKey: "FaHospital", color: "#e74c3c" },
    { name: "Garden", icon: <FaLeaf />, iconKey: "FaLeaf", color: "#2ecc71" },
    { name: "School", icon: <FaSchool />, iconKey: "FaSchool", color: "#f39c12" },
    { name: "Tools", icon: <FaTools />, iconKey: "FaTools", color: "#9b59b6" }
  ];

  // Map to convert icon strings back to React components
  const iconMap = {
    FaRoad: <FaRoad />,
    FaHospital: <FaHospital />,
    FaLeaf: <FaLeaf />,
    FaSchool: <FaSchool />,
    FaTools: <FaTools />
  };

  // State to manage projects
  const [projects, setProjects] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newProject, setNewProject] = useState({
    title: "",
    description: "",
    budget: 0,
    spent: 0,
    startDate: new Date().toISOString().split('T')[0], // Today's date in YYYY-MM-DD format
    targetCompletion: "",
    progress: 0,
    iconIndex: 0
  });
  
  // Function to generate the next project ID
  const generateNextId = () => {
    if (projects.length === 0) return "P01";
    
    // Extract numeric parts of IDs and find the maximum
    const ids = projects.map(project => {
      const match = project.id.match(/P(\d+)/);
      return match ? parseInt(match[1], 10) : 0;
    });
    
    const maxId = Math.max(...ids);
    const nextNumericId = maxId + 1;
    
    // Format with leading zeros (P01, P02, ..., P10, P11, etc.)
    return `P${nextNumericId.toString().padStart(2, '0')}`;
  };
  
  // Load projects from localStorage on initial render (simulating database fetch)
  useEffect(() => {
    const storedProjects = localStorage.getItem('barangayProjects');
    if (storedProjects) {
      // Parse the stored projects and map to add React icon components
      const parsedProjects = JSON.parse(storedProjects).map(project => ({
        ...project,
        icon: project.icon // Keep as string for storage, convert when rendering
      }));
      setProjects(parsedProjects);
    } else {
      // Initialize with sample projects if nothing in storage
      setProjects(initialProjects);
    }
  }, []);
  
  // Save projects to localStorage whenever they change (simulating database save)
  useEffect(() => {
    if (projects.length > 0) {
      localStorage.setItem('barangayProjects', JSON.stringify(projects));
    }
  }, [projects]);
  
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-PH', {
      style: 'currency',
      currency: 'PHP',
      minimumFractionDigits: 0
    }).format(amount);
  };

  // Toggle edit mode for a project
  const toggleEditMode = (id) => {
    setProjects(projects.map(project => 
      project.id === id ? { ...project, isEditing: !project.isEditing } : project
    ));
  };

  // Handle input change for project fields
  const handleInputChange = (id, field, value) => {
    setProjects(projects.map(project => {
      if (project.id === id) {
        // For spent field, automatically calculate progress
        if (field === 'spent') {
          const spent = parseFloat(value) || 0;
          const progress = Math.min(Math.round((spent / project.budget) * 100), 100);
          return { ...project, [field]: spent, progress };
        }
        // For budget field, recalculate progress based on new budget
        else if (field === 'budget') {
          const budget = parseFloat(value) || 1; // Avoid division by zero
          const progress = Math.min(Math.round((project.spent / budget) * 100), 100);
          return { ...project, [field]: budget, progress };
        }
        // For progress field directly
        else if (field === 'progress') {
          // Ensure progress is between 0 and 100
          const progress = Math.min(Math.max(parseInt(value) || 0, 0), 100);
          // Update spent based on progress
          const spent = Math.round((progress / 100) * project.budget);
          return { ...project, progress, spent };
        }
        // For other fields
        return { ...project, [field]: value };
      }
      return project;
    }));
  };

  // Handle input change for new project
  const handleNewProjectChange = (field, value) => {
    setNewProject(prev => {
      if (field === 'budget') {
        const budget = parseFloat(value) || 0;
        // Recalculate spent based on progress percentage
        const spent = Math.round((prev.progress / 100) * budget);
        return { ...prev, [field]: budget, spent };
      }
      if (field === 'progress') {
        const progress = Math.min(Math.max(parseInt(value) || 0, 0), 100);
        // Update spent based on new progress percentage
        const spent = Math.round((progress / 100) * prev.budget);
        return { ...prev, progress, spent };
      }
      if (field === 'spent') {
        const spent = parseFloat(value) || 0;
        // Update progress based on new spent amount
        const progress = prev.budget > 0 ? Math.min(Math.round((spent / prev.budget) * 100), 100) : 0;
        return { ...prev, spent, progress };
      }
      return { ...prev, [field]: value };
    });
  };

  // Add new project
  const addProject = () => {
    if (newProject.title.trim() === '') {
      alert('Project title is required');
      return;
    }

    const selectedIcon = availableIcons[newProject.iconIndex];
    
    const projectToAdd = {
      id: generateNextId(), // Generate the next sequential ID
      title: newProject.title,
      description: newProject.description,
      budget: parseFloat(newProject.budget) || 0,
      spent: parseFloat(newProject.spent) || 0,
      startDate: newProject.startDate,
      targetCompletion: newProject.targetCompletion,
      progress: newProject.progress,
      icon: selectedIcon.iconKey, // Store icon name as string for Redis compatibility
      color: selectedIcon.color,
      isEditing: false
    };

    setProjects([...projects, projectToAdd]);
    // Reset form
    setNewProject({
      title: "",
      description: "",
      budget: 0,
      spent: 0,
      startDate: new Date().toISOString().split('T')[0], // Reset to today's date
      targetCompletion: "",
      progress: 0,
      iconIndex: 0
    });
    setShowAddForm(false);
  };

  // Delete a project
  const deleteProject = (id) => {
    if (window.confirm('Are you sure you want to delete this project?')) {
      setProjects(projects.filter(project => project.id !== id));
    }
  };

  // Prepare projects for Redis-friendly format (all fields as strings)
  const prepareForRedis = (project) => {
    // Convert all values to strings for Redis
    const redisProject = {};
    for (const [key, value] of Object.entries(project)) {
      if (key === 'isEditing') continue; // Skip UI-only fields
      redisProject[key] = String(value);
    }
    return redisProject;
  };
  
  // Function to export all projects in Redis-compatible format
  const exportProjectsForRedis = () => {
    return projects.map(prepareForRedis);
  };

  return (
    <section className="projects-dashboard">
      <div className="section-header">
        <h2>
          <FaTools className="section-icon" /> 
          Barangay Development Projects
        </h2>
        <p>Track our ongoing initiatives to improve Barangay Mahayahay</p>
        
        <button 
          className="add-project-btn"
          onClick={() => setShowAddForm(!showAddForm)}
        >
          {showAddForm ? 'Cancel' : 'Add New Project'}
        </button>
      </div>

      {/* Add New Project Form */}
      {showAddForm && (
        <div className="add-project-form">
          <h3>Add New Project</h3>
          
          <div className="form-row">
            <div className="form-group">
              <label>Project Title:</label>
              <input 
                type="text" 
                value={newProject.title}
                onChange={(e) => handleNewProjectChange('title', e.target.value)}
                placeholder="Enter project title"
              />
            </div>
            
            <div className="form-group">
              <label>Icon:</label>
              <div className="icon-selector">
                {availableIcons.map((iconObj, index) => (
                  <div 
                    key={index}
                    className={`icon-option ${newProject.iconIndex === index ? 'selected' : ''}`}
                    style={{ backgroundColor: iconObj.color }}
                    onClick={() => handleNewProjectChange('iconIndex', index)}
                  >
                    {iconObj.icon}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="form-group">
            <label>Description:</label>
            <textarea 
              value={newProject.description}
              onChange={(e) => handleNewProjectChange('description', e.target.value)}
              placeholder="Enter project description"
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Budget (PHP):</label>
              <input 
                type="number" 
                value={newProject.budget}
                onChange={(e) => handleNewProjectChange('budget', e.target.value)}
                min="0"
              />
            </div>
            
            <div className="form-group">
              <label>Spent (PHP):</label>
              <input 
                type="number" 
                value={newProject.spent}
                onChange={(e) => handleNewProjectChange('spent', e.target.value)}
                min="0"
                max={newProject.budget}
              />
            </div>
            
            <div className="form-group">
              <label>Progress (%):</label>
              <input 
                type="number" 
                value={newProject.progress}
                onChange={(e) => handleNewProjectChange('progress', e.target.value)}
                min="0"
                max="100"
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Start Date:</label>
              <div className="date-input-container">
                <input 
                  type="date" 
                  value={newProject.startDate}
                  onChange={(e) => handleNewProjectChange('startDate', e.target.value)}
                  className="date-input"
                />
                <FaCalendarAlt className="calendar-icon" />
              </div>
            </div>
            
            <div className="form-group">
              <label>Target Completion:</label>
              <div className="date-input-container">
                <input 
                  type="date" 
                  value={newProject.targetCompletion}
                  onChange={(e) => handleNewProjectChange('targetCompletion', e.target.value)}
                  className="date-input"
                />
                <FaCalendarAlt className="calendar-icon" />
              </div>
            </div>
          </div>

          <div className="form-actions">
            <button 
              className="cancel-btn"
              onClick={() => setShowAddForm(false)}
            >
              <FaTimes /> Cancel
            </button>
            <button 
              className="save-btn"
              onClick={addProject}
            >
              <FaPlus /> Add Project
            </button>
          </div>
        </div>
      )}

      <div className="projects-grid">
        {projects.map(project => (
          <div key={project.id} className="project-card">
            <div className="project-header" style={{ backgroundColor: project.color }}>
              <div className="project-icon">
                {iconMap[project.icon]} {/* Render icon component from string */}
              </div>
              {project.isEditing ? (
                <input 
                  type="text"
                  value={project.title}
                  onChange={(e) => handleInputChange(project.id, 'title', e.target.value)}
                  className="edit-title"
                />
              ) : (
                <h3>{project.title}</h3>
              )}
              <div className="project-actions">
                <button 
                  onClick={() => toggleEditMode(project.id)} 
                  className="edit-button"
                >
                  {project.isEditing ? <FaSave /> : <FaEdit />}
                </button>
                <button 
                  onClick={() => deleteProject(project.id)} 
                  className="delete-button"
                >
                  <FaTrash />
                </button>
              </div>
            </div>
            
            <div className="project-body">
              <div className="project-progress">
                {project.isEditing ? (
                  <div style={{ textAlign: 'center', marginBottom: '10px' }}>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={project.progress}
                      onChange={(e) => handleInputChange(project.id, 'progress', e.target.value)}
                      style={{
                        width: '60px',
                        textAlign: 'center',
                        padding: '5px',
                        marginBottom: '5px'
                      }}
                    />
                    <label style={{ display: 'block', fontSize: '0.8rem', color: '#666' }}>% Complete</label>
                  </div>
                ) : (
                  <CircularProgressbar
                    value={project.progress}
                    text={`${project.progress}%`}
                    styles={buildStyles({
                      textSize: '1.5rem',
                      pathColor: project.color,
                      textColor: '#333',
                      trailColor: '#f0f0f0'
                    })}
                  />
                )}
              </div>
              
              <div className="project-details">
                {project.isEditing ? (
                  <textarea
                    value={project.description}
                    onChange={(e) => handleInputChange(project.id, 'description', e.target.value)}
                    className="edit-description"
                  />
                ) : (
                  <p className="project-description">{project.description}</p>
                )}
                
                <div className="project-stats">
                  <div className="stat">
                    <span className="stat-label">Project ID:</span>
                    <span className="stat-value">{project.id}</span>
                  </div>
                  <div className="stat">
                    <span className="stat-label">Budget:</span>
                    {project.isEditing ? (
                      <input
                        type="number"
                        min="0"
                        value={project.budget}
                        onChange={(e) => handleInputChange(project.id, 'budget', e.target.value)}
                        style={{ width: '120px', padding: '3px' }}
                      />
                    ) : (
                      <span className="stat-value">{formatCurrency(project.budget)}</span>
                    )}
                  </div>
                  <div className="stat">
                    <span className="stat-label">Spent:</span>
                    {project.isEditing ? (
                      <input
                        type="number"
                        min="0"
                        max={project.budget}
                        value={project.spent}
                        onChange={(e) => handleInputChange(project.id, 'spent', e.target.value)}
                        style={{ width: '120px', padding: '3px' }}
                      />
                    ) : (
                      <span className="stat-value">{formatCurrency(project.spent)}</span>
                    )}
                  </div>
                  <div className="stat">
                    <span className="stat-label">Start Date:</span>
                    {project.isEditing ? (
                      <div className="date-input-container">
                        <input
                          type="date"
                          value={project.startDate}
                          onChange={(e) => handleInputChange(project.id, 'startDate', e.target.value)}
                          className="date-input"
                        />
                        <FaCalendarAlt className="calendar-icon" />
                      </div>
                    ) : (
                      <span className="stat-value">{formatDateForDisplay(project.startDate)}</span>
                    )}
                  </div>
                  <div className="stat">
                    <span className="stat-label">Target Completion:</span>
                    {project.isEditing ? (
                      <div className="date-input-container">
                        <input
                          type="date"
                          value={project.targetCompletion}
                          onChange={(e) => handleInputChange(project.id, 'targetCompletion', e.target.value)}
                          className="date-input"
                        />
                        <FaCalendarAlt className="calendar-icon" />
                      </div>
                    ) : (
                      <span className="stat-value">{formatDateForDisplay(project.targetCompletion)}</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default ProjectsDashboard;